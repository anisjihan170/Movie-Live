package com.movielive2473.app

import android.annotation.SuppressLint
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingDestination: String? = null
    private var coins = 0
    private val prefs by lazy { getSharedPreferences("wallet", MODE_PRIVATE) }
    private val smartlink get() = getString(com.movielive2473.app.R.string.smartlink_url)
    private val rewardUrl get() = getString(com.movielive2473.app.R.string.reward_url)
    private var sponsorReturnPending = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        setContentView(R.layout.activity_main)
        coins = prefs.getInt("coins", 0)
        webView = findViewById(R.id.webView)
        configureWebView()
        findViewById<Button>(R.id.coinsButton).setOnClickListener { showRewardDialog() }
        findViewById<Button>(R.id.vipButton).setOnClickListener { showVipDialog() }
        findViewById<Button>(R.id.downloadButton).setOnClickListener { openSmartlink(null) }
        findViewById<Button>(R.id.supportButton).setOnClickListener { openExternal(getString(R.string.telegram_url)) }
        if (savedInstanceState == null) webView.loadUrl(getString(R.string.website_url)) else webView.restoreState(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (sponsorReturnPending) {
            sponsorReturnPending = false
            pendingDestination?.let { destination ->
                pendingDestination = null
                if (destination.startsWith("https://") || destination.startsWith("http://")) webView.loadUrl(destination)
            }
        }
    }

    private fun configureWebView() = webView.apply {
        settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = false; settings.allowContentAccess = false; settings.setSupportMultipleWindows(false)
        settings.userAgentString = "$userAgentString MovieLive2473/1.0"
        addJavascriptInterface(WebAppBridge(), "MovieLiveApp")
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = handleUrl(request.url.toString())
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = handleUrl(url)
            override fun onPageFinished(view: WebView, url: String) { super.onPageFinished(view, url); injectClickHooks(view) }
        }
        webChromeClient = object : WebChromeClient() { override fun onShowFileChooser(w: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams) = false }
        setBackgroundColor(Color.TRANSPARENT)
    }

    private fun handleUrl(url: String): Boolean {
        if (url.startsWith("intent:") || url.startsWith("mailto:") || url.startsWith("tel:")) { openExternal(url); return true }
        val siteHost = Uri.parse(getString(R.string.website_url)).host
        val host = runCatching { Uri.parse(url).host }.getOrNull()
        val movieAction = url.contains("download", true) || url.contains("play", true) || url.contains("watch", true) || url.endsWith(".mp4", true)
        return if (movieAction) { routeMovieAction(url); true } else host != siteHost
    }

    private fun injectClickHooks(view: WebView) { view.evaluateJavascript("""
        (function(){ if(window.__ml2473){return;} window.__ml2473=true;
        document.addEventListener('click',function(e){var a=e.target.closest('a,button'); if(!a)return; var s=((a.href||'')+' '+(a.innerText||'')).toLowerCase(); if(/download|play|watch|stream/.test(s)){e.preventDefault(); window.MovieLiveApp.movieAction(a.href||'');}},true); })();
    """.trimIndent(), null) }

    private fun openSmartlink(destination: String?) {
        pendingDestination = destination
        sponsorReturnPending = destination != null
        openExternal(smartlink)
        Toast.makeText(this, "Opening secure sponsor page…", Toast.LENGTH_SHORT).show()
    }

    private fun routeMovieAction(destination: String?) {
        if (coins <= 0) {
            Toast.makeText(this, "You need 1 coin to stream this title", Toast.LENGTH_LONG).show()
            showRewardDialog()
            return
        }
        coins -= 1
        prefs.edit().putInt("coins", coins).apply()
        openSmartlink(destination)
    }

    private fun openExternal(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    private fun showRewardDialog() {
        AlertDialog.Builder(this).setTitle("Earn free coins").setMessage("Watch a short sponsor video to receive 5 coins. Your balance: $coins")
            .setNegativeButton("Not now", null).setPositiveButton("Watch ad") { _, _ ->
                openExternal(rewardUrl)
                Toast.makeText(this, "Reward pending sponsor verification", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun showVipDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 8, 48, 0) }
        fun field(label: String, value: String): LinearLayout { val row=LinearLayout(this); row.orientation=LinearLayout.HORIZONTAL; val input=TextView(this); input.text="$label\n$value"; input.setTextColor(Color.WHITE); input.textSize=14f; input.layoutParams=LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); val copy=Button(this); copy.text="Copy"; copy.setOnClickListener { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText(label,value)); Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show() }; row.addView(input); row.addView(copy); return row }
        layout.addView(field("Binance Pay ID", getString(R.string.binance_pay_id))); layout.addView(field("USDT TRC-20 / BEP-20", getString(R.string.usdt_wallet_address)))
        val qr=ImageView(this); qr.setImageResource(android.R.drawable.ic_menu_camera); qr.contentDescription="Binance QR code placeholder"; qr.layoutParams=LinearLayout.LayoutParams(-1,180); layout.addView(qr)
        val txid=EditText(this); txid.hint="Paste your payment TxID"; txid.setTextColor(Color.WHITE); txid.setHintTextColor(Color.GRAY); layout.addView(txid)
        AlertDialog.Builder(this).setTitle("VIP Access — $1 USDT").setMessage("Send exactly 1 USDT, then submit the transaction ID for manual verification.").setView(layout).setNegativeButton("Close", null).setPositiveButton("Submit TxID") { _, _ -> if(txid.text.isNullOrBlank()) Toast.makeText(this,"Please enter a TxID",Toast.LENGTH_SHORT).show() else Toast.makeText(this,"TxID received. Support will review it manually.",Toast.LENGTH_LONG).show() }.show()
    }

    inner class WebAppBridge { @JavascriptInterface fun movieAction(destination: String) { runOnUiThread { routeMovieAction(destination.ifBlank { null }) } } }
    override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
}
