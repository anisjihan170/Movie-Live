# Keep JavaScript bridge methods callable by WebView.
-keepclassmembers class com.movielive2473.app.MainActivity$WebAppBridge { @android.webkit.JavascriptInterface <methods>; }
